import 'server-only';

import { cache } from 'react';

import { redirect } from 'next/navigation';

import { getSupabaseServerClient } from '@kit/supabase/server-client';
import { createTeamAccountsApi } from '@kit/team-accounts/api';

import pathsConfig from '~/config/paths.config';
import { requireUserInServerComponent } from '~/lib/server/require-user-in-server-component';

export type TeamAccountWorkspace = Awaited<
  ReturnType<typeof loadTeamWorkspace>
>;

/**
 * Load the account workspace data.
 * We place this function into a separate file so it can be reused in multiple places across the server components.
 *
 * This function is used in the layout component for the account workspace.
 * It is cached so that the data is only fetched once per request.
 *
 * @param accountSlug
 */
export const loadTeamWorkspace = cache(workspaceLoader);

async function workspaceLoader(accountSlug: string) {
  const client = getSupabaseServerClient();
  const api = createTeamAccountsApi(client);
  const user = await requireUserInServerComponent();

  try {
    const workspace = await api.getAccountWorkspace(accountSlug);

    // we cannot find any record for the selected account
    // so we redirect the user to the home page
    if (!workspace.data?.account) {
      return redirect(pathsConfig.app.home);
    }

    return {
      ...workspace.data,
      user,
    };
  } catch (error) {
    console.error('loadTeamWorkspace failed:', error);
    // En caso de error en la carga del workspace, redirigimos al home
    return redirect(pathsConfig.app.home);
  }
}
